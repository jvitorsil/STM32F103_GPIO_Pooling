/*
 * app.c
 *
 *  Created on: 25/07/2022
 *      Author: João Vitor Silva
 */

#include <stdint.h>
#include <stdbool.h>
#include "app.h"
#include "hw.h"

volatile uint32_t time_ms = 100;

void app_init(void){

	time_ms = 100;
}

void app_loop(void){
		/*
		 * Para deixar o código mais portatil e independente criamos o hw.c e hw.h
		 *
		  if(HAL_GPIO_ReadPin(U_Switch_GPIO_Port, U_Switch_Pin) == GPIO_PIN_RESET)
		  {
			  time_ms = 100;
		  }
		  else{
			  time_ms = 500;
		  }

		  // Comandos para piscar o LED alterando entre aceso e apagado
		HAL_GPIO_WritePin(U_LED_GPIO_Port, U_LED_Pin, GPIO_PIN_RESET);
		HAL_Delay(time_ms);
		HAL_GPIO_WritePin(U_LED_GPIO_Port, U_LED_Pin, GPIO_PIN_SET);
		HAL_Delay(time_ms);
		*/
	uint32_t led_time_ms;

	bool switch_state1 = hw_switch_state1();
	bool switch_state2 = hw_switch_state2();

	if(switch_state1 && switch_state2){

		led_time_ms = 100;
		 hw_led_state(true);
		 hw_delay_ms(led_time_ms);
		 hw_led_state(false);
		 hw_delay_ms(led_time_ms);
	}
	else{
		if(switch_state1 && !switch_state2){
			led_time_ms = 500;
		}else if(!switch_state1 && switch_state2){
			led_time_ms = 1000;
		}else if(!switch_state1 && !switch_state2){
			led_time_ms = 1500;
		}
		 hw_led_state(true);
		 hw_delay_ms(led_time_ms);
		 hw_led_state(false);
		 hw_delay_ms(led_time_ms/2);

	}


}
