/*
 * hw.c
 *
 *  Created on: 25/07/2022
 *      Author: João Vitor Silva
 */

#include "main.h"
#include <stdint.h>
#include <stdbool.h>
#include "hw.h"

bool hw_switch_state1(void){

	GPIO_PinState switch_state = HAL_GPIO_ReadPin(U_Switch_GPIO_Port, U_Switch_Pin);

	  if(switch_state == GPIO_PIN_SET){
		  return true;
	  }
	  else{
		  return false;
	  }
}
bool hw_switch_state2(void){

	GPIO_PinState switch_state = HAL_GPIO_ReadPin(U_Switch2_GPIO_Port, U_Switch2_Pin);

	  if(switch_state == GPIO_PIN_SET){
		  return true;
	  }
	  else{
		  return false;
	  }
}

void hw_led_state(bool state){
	GPIO_PinState led_state = state ? GPIO_PIN_RESET : GPIO_PIN_SET;
	HAL_GPIO_WritePin(U_LED_GPIO_Port, U_LED_Pin, led_state);
}

void hw_delay_ms(uint32_t time_ms){
	HAL_Delay(time_ms);
}
