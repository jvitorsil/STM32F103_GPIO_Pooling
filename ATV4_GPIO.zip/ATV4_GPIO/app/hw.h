/*
 * hw.h
 *
 *  Created on: 25/07/2022
 *      Author: João Vitor Silva
 */

#ifndef HW_H_
#define HW_H_

bool hw_switch_state1(void);
bool hw_switch_state2(void);
void hw_toglgle_led(void);
void hw_led_state(bool state);
void hw_delay_ms(uint32_t time_ms);

#endif /* HW_H_ */
